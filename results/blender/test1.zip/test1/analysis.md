Get-Content "yourfile.txt" | ForEach-Object {
    $parts = $_ -split "\s+"
    [PSCustomObject]@{ Address = $parts[0]; Length = [int]$parts[1] }
} | Sort-Object Length -Descending | Select-Object -First 1


The largest in malloc.log is:

Address    Length
-------    ------
0x2A6E3450 697288


